# SAYAN FF — Android playable prototype

This is an early, original top-down battle-arena gameplay prototype using the confirmed Android application ID `com.sayan.ff`.

## Current playable features
- Landscape Android gameplay screen
- Touch movement joystick (bottom-left)
- Fire control (bottom-right), auto-targets the nearest bot
- Enemy bots chase the player
- Health, eliminations, simple arena cover and restart after defeat

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location.

## Important
This is an early **2D gameplay prototype**, not a finished Free Fire-scale game and not yet an APK. It has no online multiplayer, login, 3D assets, matchmaking, voice chat, or production backend. Those require separate implementation, servers, testing, and infrastructure. All branding and gameplay assets here are original placeholders for SAYAN FF.
