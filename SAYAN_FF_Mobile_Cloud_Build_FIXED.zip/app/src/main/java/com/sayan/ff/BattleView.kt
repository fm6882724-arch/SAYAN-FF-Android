package com.sayan.ff

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class BattleView(context: Context) : View(context) {
    private data class Bot(var x: Float, var y: Float, var hp: Float = 100f)
    private data class Bullet(var x: Float, var y: Float, var vx: Float, var vy: Float)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bots = mutableListOf<Bot>()
    private val bullets = mutableListOf<Bullet>()
    private var px = 0f; private var py = 0f
    private var moveX = 0f; private var moveY = 0f
    private var joyX = 0f; private var joyY = 0f
    private var shooting = false
    private var hp = 100f
    private var kills = 0
    private var lastShot = 0L
    private var lastSpawn = 0L
    private var gameOver = false
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    init { isFocusable = true }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (px == 0f) { px = w * .5f; py = h * .52f; repeat(5) { spawn(w,h) } }
        c.drawColor(Color.rgb(31, 48, 39))
        // arena ground grid
        p.color = Color.rgb(47, 69, 53); p.strokeWidth = d(1f)
        val grid = d(48f)
        var gx = (-(px % grid))
        while (gx < w) { c.drawLine(gx,0f,gx,h,p); gx += grid }
        var gy = (-(py % grid))
        while (gy < h) { c.drawLine(0f,gy,w,gy,p); gy += grid }
        // cover rocks
        for (i in 0..8) {
            val x = ((i * 173f + w*.13f) % w); val y = ((i * 97f + h*.2f) % h)
            p.color = Color.rgb(75,82,70); c.drawRoundRect(x-d(22f),y-d(14f),x+d(22f),y+d(14f),d(8f),d(8f),p)
        }
        if (!gameOver) update(w,h)
        // bullets
        p.color = Color.YELLOW
        bullets.forEach { c.drawCircle(it.x,it.y,d(4f),p) }
        // bots
        bots.forEach {
            p.color = Color.rgb(180,55,55); c.drawCircle(it.x,it.y,d(15f),p)
            p.color = Color.BLACK; c.drawRect(it.x-d(17f),it.y-d(24f),it.x+d(17f),it.y-d(19f),p)
            p.color = Color.rgb(90,220,100); c.drawRect(it.x-d(17f),it.y-d(24f),it.x-d(17f)+d(34f)*(it.hp/100f),it.y-d(19f),p)
        }
        // player and facing
        p.color = Color.rgb(210,35,45); c.drawCircle(px,py,d(18f),p)
        p.color = Color.WHITE; c.drawCircle(px,py-d(4f),d(6f),p)
        p.color = Color.BLACK; p.textSize = d(12f); p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("S",px-d(4f),py+d(5f),p)
        // HUD
        p.color = Color.argb(190,0,0,0); c.drawRoundRect(d(12f),d(12f),d(220f),d(67f),d(10f),d(10f),p)
        p.color = Color.WHITE; p.textSize = d(16f); c.drawText("SAYAN FF  •  ALPHA",d(22f),d(34f),p)
        p.color = Color.RED; c.drawRect(d(22f),d(44f),d(202f),d(55f),p)
        p.color = Color.GREEN; c.drawRect(d(22f),d(44f),d(22f)+d(180f)*(hp/100f),d(55f),p)
        p.color = Color.WHITE; p.textSize = d(13f); c.drawText("HP ${hp.toInt()}     ELIMS $kills",d(22f),d(82f),p)
        // joystick
        p.color = Color.argb(70,255,255,255); c.drawCircle(d(82f),h-d(82f),d(52f),p)
        p.color = Color.argb(140,230,230,230); c.drawCircle(d(82f)+moveX*d(34f),h-d(82f)+moveY*d(34f),d(22f),p)
        // fire button
        p.color = Color.argb(175,185,30,35); c.drawCircle(w-d(82f),h-d(82f),d(48f),p)
        p.color = Color.WHITE; p.textSize = d(15f); p.textAlign = Paint.Align.CENTER
        c.drawText("FIRE",w-d(82f),h-d(77f),p); p.textAlign = Paint.Align.LEFT
        if (gameOver) {
            p.color = Color.argb(210,0,0,0); c.drawRect(0f,0f,w,h,p)
            p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = d(34f)
            c.drawText("MATCH OVER",w/2,h/2-d(12f),p); p.textSize = d(18f)
            c.drawText("Eliminations: $kills  •  Tap to restart",w/2,h/2+d(25f),p); p.textAlign = Paint.Align.LEFT
        }
        postInvalidateOnAnimation()
    }

    private fun update(w: Float, h: Float) {
        px = (px + moveX*d(3.8f)).coerceIn(d(20f),w-d(20f))
        py = (py + moveY*d(3.8f)).coerceIn(d(20f),h-d(20f))
        val now = System.currentTimeMillis()
        if (now-lastSpawn > 2600 && bots.size < 8) { spawn(w,h); lastSpawn = now }
        bots.forEach { b ->
            val dx = px-b.x; val dy = py-b.y; val len = hypot(dx,dy).coerceAtLeast(1f)
            b.x += dx/len*d(0.85f); b.y += dy/len*d(0.85f)
            if (len < d(30f) && now % 12L == 0L) hp -= 1.2f
        }
        if (shooting && now-lastShot > 260) {
            val target = bots.minByOrNull { hypot(it.x-px,it.y-py) }
            if (target != null) {
                val dx=target.x-px; val dy=target.y-py; val len=hypot(dx,dy).coerceAtLeast(1f)
                bullets.add(Bullet(px,py,dx/len*d(10f),dy/len*d(10f)))
            }
            lastShot=now
        }
        bullets.forEach { it.x += it.vx; it.y += it.vy }
        val it = bullets.iterator()
        while (it.hasNext()) {
            val bullet=it.next()
            val hit=bots.firstOrNull { hypot(it.x-bullet.x,it.y-bullet.y)<d(20f) }
            if (hit != null) { hit.hp -= 50f; it.remove(); if (hit.hp<=0) { bots.remove(hit); kills++ } }
            else if (bullet.x<0 || bullet.x>w || bullet.y<0 || bullet.y>h) it.remove()
        }
        if (hp<=0f) gameOver=true
    }

    private fun spawn(w: Float,h: Float) {
        val side=Random.nextInt(4)
        val x=when(side){0->d(10f);1->w-d(10f);else->Random.nextFloat()*w}
        val y=when(side){2->d(10f);3->h-d(10f);else->Random.nextFloat()*h}
        bots.add(Bot(x,y))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w=width.toFloat(); val h=height.toFloat()
        if (gameOver && e.action==MotionEvent.ACTION_DOWN) {
            hp=100f; kills=0; bots.clear(); bullets.clear(); gameOver=false; px=w/2; py=h/2; repeat(5){spawn(w,h)}; return true
        }
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> {
                var foundJoy=false; var foundFire=false
                for (i in 0 until e.pointerCount) {
                    val x=e.getX(i); val y=e.getY(i)
                    if (x < w*.45f && y > h*.48f) {
                        val dx=(x-d(82f))/d(52f); val dy=(y-(h-d(82f)))/d(52f)
                        val len=hypot(dx,dy).coerceAtLeast(1f); moveX=(dx/len).coerceIn(-1f,1f); moveY=(dy/len).coerceIn(-1f,1f); foundJoy=true
                    }
                    if (x > w*.72f && y > h*.48f) { shooting=true; foundFire=true }
                }
                if (!foundJoy) { moveX=0f; moveY=0f }
                if (!foundFire && e.actionMasked==MotionEvent.ACTION_MOVE) shooting=false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                moveX=0f; moveY=0f; shooting=false
            }
        }
        return true
    }
}
